# The Student Corner

A responsive student magazine made with HTML5 and CSS3. Open `index.html` directly in a browser. No installation, build, JavaScript, framework, or network connection is needed for the site itself.

## Pages and assets

All 15 original HTML pages are preserved. Every page uses `css/style.css`. Images and the shared SVG logo live in `images/`. Local links are relative and case-sensitive-host compatible. External educational resources require an internet connection.

Navigation uses native HTML details/summary on smaller screens. Checklists work with native checkboxes. Tables scroll within labeled keyboard-accessible regions. Contact and contributor fields are explicitly unsaved drafting spaces; there is no form delivery service or published contact address.

## GitHub Pages

Upload the HTML files, `css/`, `images/`, and `.nojekyll` to your repository root. In Settings → Pages choose Deploy from a branch, select the branch and `/ (root)`, then save. No build command is required. Relative links work under a repository subpath.

`public/the-student-corner.zip` is a portable copy of the same static site.
